
// Função para buscar e exibir eventos com link para página de detalhes
async function loadEventos() {
    try {
        const response = await fetch('http://localhost:3000/eventos');
        const eventos = await response.json();

        const eventList = document.getElementById('event-list');
        if (eventList) { // Verificar se o elemento existe antes de tentar manipular
            eventList.innerHTML = ''; // Limpar conteúdo existente

            eventos.forEach(evento => {
                const placeCard = document.createElement('a');
                placeCard.className = 'place-card';
                placeCard.href = `${evento.link}`; // Redirecionar para a página de detalhes com o ID do evento na URL
                placeCard.innerHTML = `
                    <img src="${evento.fotos && evento.fotos[0] ? evento.fotos[0] : './600x200.png'}" alt="${evento.nome}">
                    <h2>${evento.nome}</h2>
                    <p>${evento.descricao}</p>
                    <p>Data de início: ${evento.dataInicio}</p>
                    <p>Data de fim: ${evento.dataFim}</p>
                    <div class="details">
                        <span>Local: ${evento.local}</span>
                    </div>
                `;
                eventList.appendChild(placeCard);
            });
        }
    } catch (error) {
        console.error('Erro ao buscar eventos:', error);
    }
}

async function loadEvento() {
    try {
        const response = await fetch('http://localhost:3000/evento');
        const eventos = await response.json();

        const eventList = document.getElementById('event-list');
        if (eventList) { // Verificar se o elemento existe antes de tentar manipular
            eventList.innerHTML = ''; // Limpar conteúdo existente

            eventos.forEach(evento => {
                const placeCard = document.createElement('a');
                placeCard.className = 'place-card';
                placeCard.href = `/evento.html?id=${evento._id}`; // Redirecionar para a página de detalhes com o ID do evento na URL
                placeCard.innerHTML = `
                    <img src="${evento.fotos && evento.fotos[0] ? evento.fotos[0] : './600x200.png'}" alt="${evento.nome}">
                    <h2>${evento.nome}</h2>
                    <p>${evento.descricao}</p>
                    <p>Data de início: ${evento.dataInicio}</p>
                    <p>Data de fim: ${evento.dataFim}</p>
                    <div class="details">
                        <span>Local: ${evento.local}</span>
                    </div>
                `;
                eventList.appendChild(placeCard);
            });
        }
    } catch (error) {
        console.error('Erro ao buscar eventos:', error);
    }
}
async function loadParques() {
    try {
        const response = await fetch('http://localhost:3000/parque');
        const eventos = await response.json();

        const eventList = document.getElementById('event-list');
        if (eventList) { // Verificar se o elemento existe antes de tentar manipular
            eventList.innerHTML = ''; // Limpar conteúdo existente

            eventos.forEach(evento => {
                const placeCard = document.createElement('a');
                placeCard.className = 'place-card';
                placeCard.href = `/evento.html?id=${evento._id}`; // Redirecionar para a página de detalhes com o ID do evento na URL
                placeCard.innerHTML = `
                    <img src="${evento.fotos && evento.fotos[0] ? evento.fotos[0] : './600x200.png'}" alt="${evento.nome}">
                    <h2>${evento.nome}</h2>
                    <p>${evento.descricao}</p>
                    <p>Data de início: ${evento.dataInicio}</p>
                    <p>Data de fim: ${evento.dataFim}</p>
                    <div class="details">
                        <span>Local: ${evento.local}</span>
                    </div>
                `;
                eventList.appendChild(placeCard);
            });
        }
    } catch (error) {
        console.error('Erro ao buscar eventos:', error);
    }

   
}

async function loadPracas() {
    try {
        const response = await fetch('http://localhost:3000/pracas');
        const eventos = await response.json();

        const eventList = document.getElementById('event-list');
        if (eventList) { // Verificar se o elemento existe antes de tentar manipular
            eventList.innerHTML = ''; // Limpar conteúdo existente

            eventos.forEach(evento => {
                const placeCard = document.createElement('a');
                placeCard.className = 'place-card';
                placeCard.href = `/evento.html?id=${evento._id}`; // Redirecionar para a página de detalhes com o ID do evento na URL
                placeCard.innerHTML = `
                    <img src="${evento.fotos && evento.fotos[0] ? evento.fotos[0] : './600x200.png'}" alt="${evento.nome}">
                    <h2>${evento.nome}</h2>
                    <p>${evento.descricao}</p>
                    <p>Data de início: ${evento.dataInicio}</p>
                    <p>Data de fim: ${evento.dataFim}</p>
                    <div class="details">
                        <span>Local: ${evento.local}</span>
                    </div>
                `;
                eventList.appendChild(placeCard);
            });
        }
    } catch (error) {
        console.error('Erro ao buscar eventos:', error);
    }
} 
async function loadZoologico() {
    try {
        const response = await fetch('http://localhost:3000/zoologico');
        const eventos = await response.json();

        const eventList = document.getElementById('event-list');
        if (eventList) { // Verificar se o elemento existe antes de tentar manipular
            eventList.innerHTML = ''; // Limpar conteúdo existente

            eventos.forEach(evento => {
                const placeCard = document.createElement('a');
                placeCard.className = 'place-card';
                placeCard.href = `/evento.html?id=${evento._id}`; // Redirecionar para a página de detalhes com o ID do evento na URL
                placeCard.innerHTML = `
                    <img src="${evento.fotos && evento.fotos[0] ? evento.fotos[0] : './600x200.png'}" alt="${evento.nome}">
                    <h2>${evento.nome}</h2>
                    <p>${evento.descricao}</p>
                    <p>Data de início: ${evento.dataInicio}</p>
                    <p>Data de fim: ${evento.dataFim}</p>
                    <div class="details">
                        <span>Local: ${evento.local}</span>
                    </div>
                `;
                eventList.appendChild(placeCard);
            });
        }
    } catch (error) {
        console.error('Erro ao buscar eventos:', error);
    }
}

async function loadShopping() {
    try {
        const response = await fetch('http://localhost:3000/shopping');
        const eventos = await response.json();

        const eventList = document.getElementById('event-list');
        if (eventList) { // Verificar se o elemento existe antes de tentar manipular
            eventList.innerHTML = ''; // Limpar conteúdo existente

            eventos.forEach(evento => {
                const placeCard = document.createElement('a');
                placeCard.className = 'place-card';
                placeCard.href = `/evento.html?id=${evento._id}`; // Redirecionar para a página de detalhes com o ID do evento na URL
                placeCard.innerHTML = `
                    <img src="${evento.fotos && evento.fotos[0] ? evento.fotos[0] : './600x200.png'}" alt="${evento.nome}">
                    <h2>${evento.nome}</h2>
                    <p>${evento.descricao}</p>
                    <p>Data de início: ${evento.dataInicio}</p>
                    <p>Data de fim: ${evento.dataFim}</p>
                    <div class="details">
                        <span>Local: ${evento.local}</span>
                    </div>
                `;
                eventList.appendChild(placeCard);
            });
        }
    } catch (error) {
        console.error('Erro ao buscar eventos:', error);
    }
}

async function loadSesc() {
    try {
        const response = await fetch('http://localhost:3000/sesc');
        const eventos = await response.json();

        const eventList = document.getElementById('event-list');
        if (eventList) { // Verificar se o elemento existe antes de tentar manipular
            eventList.innerHTML = ''; // Limpar conteúdo existente

            eventos.forEach(evento => {
                const placeCard = document.createElement('a');
                placeCard.className = 'place-card';
                placeCard.href = `/evento.html?id=${evento._id}`; // Redirecionar para a página de detalhes com o ID do evento na URL
                placeCard.innerHTML = `
                    <img src="${evento.fotos && evento.fotos[0] ? evento.fotos[0] : './600x200.png'}" alt="${evento.nome}">
                    <h2>${evento.nome}</h2>
                    <p>${evento.descricao}</p>
                    <p>Data de início: ${evento.dataInicio}</p>
                    <p>Data de fim: ${evento.dataFim}</p>
                    <div class="details">
                        <span>Local: ${evento.local}</span>
                    </div>
                `;
                eventList.appendChild(placeCard);
            });
        }
    } catch (error) {
        console.error('Erro ao buscar eventos:', error);
    }
}

async function loadAquario() {
    try {
        const response = await fetch('http://localhost:3000/aquario');
        const eventos = await response.json();

        const eventList = document.getElementById('event-list');
        if (eventList) { // Verificar se o elemento existe antes de tentar manipular
            eventList.innerHTML = ''; // Limpar conteúdo existente

            eventos.forEach(evento => {
                const placeCard = document.createElement('a');
                placeCard.className = 'place-card';
                placeCard.href = `/evento.html?id=${evento._id}`; // Redirecionar para a página de detalhes com o ID do evento na URL
                placeCard.innerHTML = `
                    <img src="${evento.fotos && evento.fotos[0] ? evento.fotos[0] : './600x200.png'}" alt="${evento.nome}">
                    <h2>${evento.nome}</h2>
                    <p>${evento.descricao}</p>
                    <p>Data de início: ${evento.dataInicio}</p>
                    <p>Data de fim: ${evento.dataFim}</p>
                    <div class="details">
                        <span>Local: ${evento.local}</span>
                    </div>
                `;
                eventList.appendChild(placeCard);
            });
        }
    } catch (error) {
        console.error('Erro ao buscar eventos:', error);
    }
}
// Função para buscar eventos com pesquisa
function buscarEventos() {
    const conteudo = document.getElementById('event-list');
    conteudo.innerHTML = ''; // Limpar o conteúdo antes de exibir novos resultados

    // Obter o valor da barra de pesquisa
    const palavra = document.getElementById('search-text').value;

    // Atualizar o título para mostrar o termo pesquisado
    document.querySelector("h2").innerHTML = `Você pesquisou por: ${palavra}`;

    // Fazer a requisição à API para buscar eventos
    fetch(`http://localhost:3000/eventos/${palavra}`)  // URL usa o valor pesquisado
        .then((res) => res.json())
        .then((dados) => {
            if (dados.length === 0) {
                conteudo.innerHTML = '<p>Nenhum evento encontrado.</p>';
            } else {
                dados.map((evento) => {
                    const card = `
                    <a class="place-card" href="/eventos/${evento._id}">
                        <img src="${evento.fotos && evento.fotos[0] ? evento.fotos[0] : './600x200.png'}" alt="${evento.nome}">
                        <div class="card-body">
                            <h2 class="card-title">${evento.nome}</h2>
                            <p class="card-text">${evento.descricao}</p>
                            <h3 class="card-text">Data: ${evento.dataInicio} - ${evento.dataFim}</h3>
                            <div class="details">
                                <span>Local: ${evento.local}</span>
                            </div>
                        </div>
                    </a>`;
                    conteudo.innerHTML += card; // Adicionar o card ao conteúdo
                });
            }
        })
        .catch((error) => console.error(`Erro ao buscar eventos: ${error}`));
}

// Adicionar listener ao botão de pesquisa
document.getElementById('search-submit').addEventListener('click', buscarEventos);

// // Carregar todos os dados ao carregar a página
// document.addEventListener('DOMContentLoaded', () => {
//     loadEventos();
//     loadEvento()
//     loadParques()
//     loadPracas()
// });




